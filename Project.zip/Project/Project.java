/*  A Java Hello World Console Application */
import java.util.Calendar;
import java.lang.Math;
import java.util.Random;
import java.net.Socket;
import java.io.*;
import java.util.concurrent.*;
import java.net.ServerSocket;

public class Project {

//The vector clock that we will use
public static int[] vectorClock = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static int vector = 0;
public static int id = 0;

public static String Messages; //Where our messages will be delivered
   

public static void main (String args[]) {
      
      System.out.println(snapshot() + " Process Started.");
      if (args.length < 1){
      System.out.println(snapshot() + " Not enough arguments specified, exiting");
      return;
      }

      System.out.println(snapshot() + " New Process Started with ID: " 
      + args[0]
      );
      
      String port = ReadLine(Integer.parseInt(args[0]));
      System.out.println(snapshot() + " SERVER PORT: " + Integer.parseInt(port));
      
      
      id = Integer.parseInt(args[0]);
      //Create a new TCP Server on the specified port
      Server.start(Integer.parseInt(port), Integer.parseInt(args[0]));
      //Create a new TCP Client and start it running
      Client.sendmessage(Integer.parseInt(args[0]));
      
      //Move on to the main thread
      System.out.println(snapshot() + " Server thread successfully started from main thread");
      
      //Save the output
      saveFile(Integer.parseInt(args[0]), Messages);
    	}
   
   public static String snapshot()
   {
      return "(Time at " + Calendar.getInstance().get(Calendar.MILLISECOND) + " milliseconds)";
   }
    //Retrieves the connection information from setup.txt
   public static String ReadLine(int id)
   {
   String line = "ERROR reading file";
   try(BufferedReader br = new BufferedReader(new FileReader("setup.txt"))) 
    {
    for (int i = 0; i <= id; i++)
    line = br.readLine();
    
    }
    catch(Exception e){}
    return line;
   }
   
   
   public static void saveFile(int a, String messages)
   {
   
      //Write the file used to save the data
      Writer writer = null;
      
      try {
          writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream("process" + a + "_msg.txt"), "utf-8"));
          writer.write(messages);
      } 
        catch (IOException ex) {
        // report
      } finally {
         try {writer.close();} catch (Exception ex) {/*ignore*/}
      }
   }
      
  
   //Threaded Server
   static class Server
   {
   //Start the server on a new thread
       public static void start(int port, int id) {
        new Server().startServer(port, id);
   }

    public void startServer(int port, int id) {
    
        final ExecutorService clientProcessingPool = Executors.newFixedThreadPool(10);

        Runnable serverTask = new Runnable() {
            @Override
            public void run() {
                try {
                    ServerSocket serverSocket = new ServerSocket(port);
                    System.out.println(snapshot() + " waiting for clients");
                    while (true) {
                        Socket clientSocket = serverSocket.accept();
                        clientProcessingPool.submit(new HandleClient(clientSocket));
                    }
                } catch (IOException e) {
                    System.err.println("Error, unable to process client request");
                    e.printStackTrace();
                }
            }
        };
        Thread serverThread = new Thread(serverTask);
        serverThread.start();

    }

    private static class HandleClient implements Runnable {
        
        public int id = 0;
        private HandleClient(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

         private final Socket clientSocket;

        @Override
        public void run() {
        String vectorC = ""; //Processes the vector clock   
        int recID = 0; //The ID of the process that sent the message 
        boolean pass = true;
        
        try {
              BufferedReader inFromClient =  new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
              String clientSentence = inFromClient.readLine();
            
         
              System.out.println(snapshot() + "Received Message: " + clientSentence + "");
              //Analyze the vector clock of the message
              vectorC = clientSentence.substring(0,21);
              
              System.out.println("Vector Clock of message: " + vectorC);
              System.out.println("ID of the sending process: " + recID);
              System.out.println("ID of the parent process: " + id);
             
              //Check Rule 1.a of Birman-Schiper-Stephenson Protocol
              //Cj[i] = tm[i] - 1;
              if (!((Integer.parseInt(clientSentence.substring(2*recID)) - 1) == Integer.parseInt(clientSentence.substring(2*id))))
              {System.out.println(snapshot() + "1a. Message has failed criteria for delivery");
              pass = false;}
              //Check Rule 1.b of Birman-Schiper-Stephenson Protocol
              //for all k <= n and k != i, Cj[k] <= tm[k].
              for (int i = 0; i < 10; i++)
              if (!((Integer.parseInt(clientSentence.substring(2*id))) <= Integer.parseInt(clientSentence.substring(2*i))))
              {System.out.println(snapshot() + "1a. Message has failed criteria for delivery");
              pass = false;}
              
              if (pass == false){
              System.out.println("Message has been rejected for delivery and added to the queue.");
              }
              
              if (pass == true){
              System.out.println("Message has been delivered.");
              Messages += clientSentence;}
              
              
              System.out.println("Analyzing messages in queue for casual ordering");
            }
            catch(Exception e)
              {
               System.out.println("Error reading information");
              }
        
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
   }
   
   static class Client
   {
   
        public static void sendmessage(int id)
        {
        
        Socket clientSocket;
        
        String[] ports = new String[10];
        try(BufferedReader br = new BufferedReader(new FileReader("setup.txt"))) 
          {
          for (int i = 0; i < 10; i++)
          if (i != id) //Don't send information to ourselves
          ports[i] = br.readLine();
          else
          {
          br.readLine();
          ports[i] = "0"; //Just send it to null port
          }
          
          }
          catch(Exception e){}
          
         


      int n = 0;
      //Create a new random
      Random rand = new Random();
      
      //Send message every 3 seconds for 90 seconds
      while (n++ < 30) {
      boolean success = true;  
	      double d = rand.nextDouble();	// 0 <= d <= 1
         if (d >= 0.5)
         
	//if d >= 0.5, then send a message to all the peers.
   
        System.out.println(snapshot() + "Sending messages. Current Vector Clock: " +
        "(" + vectorClock[0] + "," +
        vectorClock[1] + "," +
        vectorClock[2] + "," +
        vectorClock[3] + "," +
        vectorClock[4] + "," +
        vectorClock[5] + "," +
        vectorClock[6] + "," +
        vectorClock[7] + "," +
        vectorClock[8] + "," +
        vectorClock[9] + ")" );
        for (int i = 0; i < 10; i++)
        {
        try
        {
        
        clientSocket = new Socket("localhost", Integer.parseInt(ports[i]));
        DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
        outToServer.writeBytes(
        "(" + vectorClock[0] + "," +
        vectorClock[1] + "," +
        vectorClock[2] + "," +
        vectorClock[3] + "," +
        vectorClock[4] + "," +
        vectorClock[5] + "," +
        vectorClock[6] + "," +
        vectorClock[7] + "," +
        vectorClock[8] + "," +
        vectorClock[9] + 
        ") <Process ID " + id + " Hello others!>");
        
        //Increment our vector clock
        
        clientSocket.close();
        }
        
        
        
        catch(Exception e)
        {
        System.out.println("Error in sending information to port " + ports[i] + "! Not all servers are reachable");
        success = false;
        }
        if (success == true)
        {
        vector++;
        System.out.println("Incremented vector clock " + vector + " times");
        vectorClock[id] = vector;
        }
        
        }
        
        
        
            //Sleep for 3 seconds
            try
            {
   	      Thread.sleep (3000);
            }
            catch(Exception e)
            {
            System.out.println("Error putting PC in sleepmode");
            }
         }

        
        
        }
  
   }   

}